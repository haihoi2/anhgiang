Drupal.locale = { 'pluralFormula': function ($n) { return Number(($n>1)); }, 'strings': {"":{"An AJAX HTTP error occurred.":"C\u00f3 l\u1ed7i AJAX HTTP.","HTTP Result Code: !status":"K\u1ebft qu\u1ea3 m\u00e3 HTTP: !status","An AJAX HTTP request terminated abnormally.":"Y\u00eau c\u1ea7u AJAX HTTP k\u1ebft th\u00fac b\u1ea5t th\u01b0\u1eddng.","Debugging information follows.":"R\u00e0 l\u1ed7i theo th\u00f4ng tin sau.","Path: !uri":"\u0110\u01b0\u1eddng d\u1eabn: !uri","StatusText: !statusText":"StatusText: !statusText","ResponseText: !responseText":"ResponseTextt: !responseText","ReadyState: !readyState":"ReadyState: !readyState","Loading":"\u0110ang n\u1ea1p","(active tab)":"(tab ho\u1ea1t \u0111\u1ed9ng)","All":"T\u1ea5t c\u1ea3","New":"M\u1edbi","@title dialog":"H\u1ed9p tho\u1ea1i @title","Configure":"C\u1ea5u h\u00ecnh","Show shortcuts":"Hi\u1ec7n li\u00ean k\u1ebft nhanh","Hide shortcuts":"\u1ea8n li\u00ean k\u1ebft nhanh","Select all rows in this table":"Ch\u1ecdn t\u1ea5t c\u1ea3 c\u00e1c d\u00f2ng trong b\u1ea3ng n\u00e0y","Deselect all rows in this table":"B\u1ecf ch\u1ecdn t\u1ea5t c\u1ea3 c\u00e1c d\u00f2ng trong b\u1ea3ng n\u00e0y","Hide":"\u1ea8n","Show":"Hi\u1ec7n","Edit":"S\u1eeda","Re-order rows by numerical weight instead of dragging.":"S\u1eafp x\u1ebfp l\u1ea1i danh m\u1ee5c theo \u0111\u1ed9 n\u1eb7ng thay v\u00ec k\u00e9o ch\u00fang.","Show row weights":"Hi\u1ec7n tr\u1ecdng s\u1ed1 h\u00e0ng","Hide row weights":"\u1ea8n tr\u1ecdng s\u1ed1 h\u00e0ng","Drag to re-order":"K\u00e9o \u0111\u1ec3 s\u1eafp x\u1ebfp l\u1ea1i","Changes made in this table will not be saved until the form is submitted.":"C\u00e1c thay \u0111\u1ed5i \u0111\u01b0\u1ee3c th\u1ef1c hi\u1ec7n trong b\u1ea3ng n\u00e0y s\u1ebd kh\u00f4ng \u0111\u01b0\u1ee3c l\u01b0u cho \u0111\u1ebfn khi bi\u1ec3u m\u1eabu \u0111\u01b0\u1ee3c \u0111\u1ec7 tr\u00ecnh.","Please wait...":"Vui l\u00f2ng \u0111\u1ee3i...","Hide summary":"\u1ea8n t\u00f3m t\u1eaft","Edit summary":"S\u1eeda t\u00f3m t\u1eaft","Not in menu":"Kh\u00f4ng c\u00f3 trong tr\u00ecnh \u0111\u01a1n","New revision":"Phi\u00ean b\u1ea3n m\u1edbi","No revision":"Kh\u00f4ng c\u00f3 phi\u00ean b\u1ea3n n\u00e0o","By @name on @date":"B\u1edfi @name v\u00e0o l\u00fac @date","By @name":"@name vi\u1ebft","Not published":"Ch\u01b0a c\u00f4ng b\u1ed1","Alias: @alias":"\u0110\u01b0\u1eddng d\u1eabn \u1ea3o: @alias","No alias":"Ch\u01b0a c\u00f3 \u0111\u01b0\u1eddng d\u1eabn \u1ea3o","@number comments per page":"@number l\u1eddi b\u00ecnh m\u1ed7i trang","Autocomplete popup":"B\u1eadt l\u00ean t\u1ef1 ho\u00e0n t\u1ea5t","Searching for matches...":"T\u00ecm kh\u1edbp...","Home":"Nh\u00e0","Disabled":"T\u1eaft","Enabled":"B\u1eadt","Submit":"G\u1eedi \u0111i","Add":"Th\u00eam","Not restricted":"Kh\u00f4ng h\u1ea1n ch\u1ebf","Restricted to certain pages":"H\u1ea1n ch\u1ebf \u0111\u1ed1i v\u1edbi m\u1ed9t s\u1ed1 trang","Not customizable":"Ng\u01b0\u1eddi d\u00f9ng kh\u00f4ng \u0111\u01b0\u1ee3c ph\u00e9p t\u00f9y ch\u1ec9nh","The changes to these blocks will not be saved until the \u003Cem\u003ESave blocks\u003C\/em\u003E button is clicked.":"C\u00e1c thay \u0111\u1ed5i \u0111\u1ed1i v\u1edbi c\u00e1c kh\u1ed1i n\u1ed9i dung n\u00e0y s\u1ebd ch\u01b0a \u0111\u01b0\u1ee3c l\u01b0u cho \u0111\u1ebfn khi n\u00fat \u003Cem\u003EL\u01b0u c\u00e1c kh\u1ed1i n\u1ed9i dung\u003C\/em\u003E \u0111\u01b0\u1ee3c nh\u1ea5p.","The block cannot be placed in this region.":"Kh\u00f4ng th\u1ec3 \u0111\u01b0a kh\u1ed1i n\u00e0y v\u00e0o v\u00f9ng n\u00e0y.","Cancel":"H\u1ee7y b\u1ecf","all":"t\u1ea5t c\u1ea3","none":"kh\u00f4ng c\u00f3","Upload":"T\u1ea3i l\u00ean","Loading...":"\u0110ang n\u1ea1p...","Refresh":"L\u00e0m t\u01b0\u01a1i","OK":"OK","Only files with the following extensions are allowed: %files-allowed.":"Ch\u1ec9 nh\u1eefng t\u1eadp tin c\u00f3 ph\u1ea7n m\u1edf r\u1ed9ng sau m\u1edbi \u0111\u01b0\u1ee3c ph\u00e9p: %files-allowed.","This permission is inherited from the authenticated user role.":"Quy\u1ec1n n\u00e0y \u0111\u01b0\u1ee3c k\u1ebf th\u1eeba t\u1eeb vai tr\u00f2 ng\u01b0\u1eddi d\u00f9ng \u0111\u00e3 x\u00e1c th\u1ef1c.","Requires a title":"Ph\u1ea7n ti\u00eau \u0111\u1ec1 l\u00e0 b\u1eaft bu\u1ed9c","Don\u0027t display post information":"Hi\u1ec3n th\u1ecb tho\u1ea1i th\u00f4ng tin ch\u1eef","The selected file %filename cannot be uploaded. Only files with the following extensions are allowed: %extensions.":"T\u00ean t\u1ec7p %filename kh\u00f4ng \u0111\u01b0\u1ee3c ph\u00e9p t\u1ea3i l\u00ean. Ch\u1ec9 c\u00f3 c\u00e1c t\u1ec7p v\u1edbi ph\u1ea7n m\u1edf r\u1ed9ng sau l\u00e0 \u0111\u01b0\u1ee3c ph\u00e9p: %extensions.","Select all":"Ch\u1ecdn t\u1ea5t c\u1ea3","Close":"\u0110\u00f3ng","Please select a file.":"Vui l\u00f2ng ch\u1ecdn m\u1ed9t t\u1eadp tin.","You are not allowed to operate on more than %num files.":"B\u1ea1n kh\u00f4ng \u0111\u01b0\u1ee3c ph\u00e9p thao t\u00e1c nhi\u1ec1u h\u01a1n %num t\u1eadp tin.","Please specify dimensions within the allowed range that is from 1x1 to @dimensions.":"Vui l\u00f2ng x\u00e1c \u0111\u1ecbnh k\u00edch th\u01b0\u1edbc trong kho\u1ea3ng cho ph\u00e9p t\u1eeb 1x1 \u0111\u1ebfn @dimensions.","%filename is not an image.":"%filename kh\u00f4ng ph\u1ea3i l\u00e0 m\u1ed9t \u1ea3nh","Do you want to refresh the current directory?":"B\u1ea1n c\u00f3 c\u00f3 mu\u1ed1n l\u00e0m t\u01b0\u01a1i th\u01b0 m\u1ee5c hi\u1ec7n h\u00e0nh?","Delete selected files?":"X\u00f3a c\u00e1c t\u1eadp tin \u0111\u00e3 ch\u1ecdn?","Please select a thumbnail.":"Vui l\u00f2ng ch\u1ecdn m\u1ed9t \u1ea3nh thu nh\u1ecf.","You must select at least %num files.":"B\u1ea1n ph\u1ea3i ch\u1ecdn \u00edt nh\u1ea5t %num t\u1eadp tin.","Insert file":"Ch\u00e8n t\u1eadp tin v\u00e0o","Add file":"Th\u00eam t\u1eadp tin","Select":"Ch\u1ecdn","Automatic alias":"\u0110\u01b0\u1eddng d\u1eabn \u1ea3o t\u1ef1 \u0111\u1ed9ng","Remove group":"X\u00f3a nh\u00f3m","Revert to default":"\u0110\u1eb7t l\u1ea1i v\u1ec1 m\u1eb7c \u0111\u1ecbnh"}} };;
(function ($) {

Drupal.behaviors.tableSelect = {
  attach: function (context, settings) {
    // Select the inner-most table in case of nested tables.
    $('th.select-all', context).closest('table').once('table-select', Drupal.tableSelect);
  }
};

Drupal.tableSelect = function () {
  // Do not add a "Select all" checkbox if there are no rows with checkboxes in the table
  if ($('td input:checkbox', this).length == 0) {
    return;
  }

  // Keep track of the table, which checkbox is checked and alias the settings.
  var table = this, checkboxes, lastChecked;
  var strings = { 'selectAll': Drupal.t('Select all rows in this table'), 'selectNone': Drupal.t('Deselect all rows in this table') };
  var updateSelectAll = function (state) {
    // Update table's select-all checkbox (and sticky header's if available).
    $(table).prev('table.sticky-header').andSelf().find('th.select-all input:checkbox').each(function() {
      $(this).attr('title', state ? strings.selectNone : strings.selectAll);
      this.checked = state;
    });
  };

  // Find all <th> with class select-all, and insert the check all checkbox.
  $('th.select-all', table).prepend($('<input type="checkbox" class="form-checkbox" />').attr('title', strings.selectAll)).click(function (event) {
    if ($(event.target).is('input:checkbox')) {
      // Loop through all checkboxes and set their state to the select all checkbox' state.
      checkboxes.each(function () {
        this.checked = event.target.checked;
        // Either add or remove the selected class based on the state of the check all checkbox.
        $(this).closest('tr').toggleClass('selected', this.checked);
      });
      // Update the title and the state of the check all box.
      updateSelectAll(event.target.checked);
    }
  });

  // For each of the checkboxes within the table that are not disabled.
  checkboxes = $('td input:checkbox:enabled', table).click(function (e) {
    // Either add or remove the selected class based on the state of the check all checkbox.
    $(this).closest('tr').toggleClass('selected', this.checked);

    // If this is a shift click, we need to highlight everything in the range.
    // Also make sure that we are actually checking checkboxes over a range and
    // that a checkbox has been checked or unchecked before.
    if (e.shiftKey && lastChecked && lastChecked != e.target) {
      // We use the checkbox's parent TR to do our range searching.
      Drupal.tableSelectRange($(e.target).closest('tr')[0], $(lastChecked).closest('tr')[0], e.target.checked);
    }

    // If all checkboxes are checked, make sure the select-all one is checked too, otherwise keep unchecked.
    updateSelectAll((checkboxes.length == $(checkboxes).filter(':checked').length));

    // Keep track of the last checked checkbox.
    lastChecked = e.target;
  });

  // If all checkboxes are checked on page load, make sure the select-all one
  // is checked too, otherwise keep unchecked.
  updateSelectAll((checkboxes.length == $(checkboxes).filter(':checked').length));
};

Drupal.tableSelectRange = function (from, to, state) {
  // We determine the looping mode based on the order of from and to.
  var mode = from.rowIndex > to.rowIndex ? 'previousSibling' : 'nextSibling';

  // Traverse through the sibling nodes.
  for (var i = from[mode]; i; i = i[mode]) {
    // Make sure that we're only dealing with elements.
    if (i.nodeType != 1) {
      continue;
    }

    // Either add or remove the selected class based on the state of the target checkbox.
    $(i).toggleClass('selected', state);
    $('input:checkbox', i).each(function () {
      this.checked = state;
    });

    if (to.nodeType) {
      // If we are at the end of the range, stop.
      if (i == to) {
        break;
      }
    }
    // A faster alternative to doing $(i).filter(to).length.
    else if ($.filter(to, [i]).r.length) {
      break;
    }
  }
};

})(jQuery);
;
(function ($) {

/**
 * Attaches sticky table headers.
 */
Drupal.behaviors.tableHeader = {
  attach: function (context, settings) {
    if (!$.support.positionFixed) {
      return;
    }

    $('table.sticky-enabled', context).once('tableheader', function () {
      $(this).data("drupal-tableheader", new Drupal.tableHeader(this));
    });
  }
};

/**
 * Constructor for the tableHeader object. Provides sticky table headers.
 *
 * @param table
 *   DOM object for the table to add a sticky header to.
 */
Drupal.tableHeader = function (table) {
  var self = this;

  this.originalTable = $(table);
  this.originalHeader = $(table).children('thead');
  this.originalHeaderCells = this.originalHeader.find('> tr > th');
  this.displayWeight = null;

  // React to columns change to avoid making checks in the scroll callback.
  this.originalTable.bind('columnschange', function (e, display) {
    // This will force header size to be calculated on scroll.
    self.widthCalculated = (self.displayWeight !== null && self.displayWeight === display);
    self.displayWeight = display;
  });

  // Clone the table header so it inherits original jQuery properties. Hide
  // the table to avoid a flash of the header clone upon page load.
  this.stickyTable = $('<table class="sticky-header"/>')
    .insertBefore(this.originalTable)
    .css({ position: 'fixed', top: '0px' });
  this.stickyHeader = this.originalHeader.clone(true)
    .hide()
    .appendTo(this.stickyTable);
  this.stickyHeaderCells = this.stickyHeader.find('> tr > th');

  this.originalTable.addClass('sticky-table');
  $(window)
    .bind('scroll.drupal-tableheader', $.proxy(this, 'eventhandlerRecalculateStickyHeader'))
    .bind('resize.drupal-tableheader', { calculateWidth: true }, $.proxy(this, 'eventhandlerRecalculateStickyHeader'))
    // Make sure the anchor being scrolled into view is not hidden beneath the
    // sticky table header. Adjust the scrollTop if it does.
    .bind('drupalDisplaceAnchor.drupal-tableheader', function () {
      window.scrollBy(0, -self.stickyTable.outerHeight());
    })
    // Make sure the element being focused is not hidden beneath the sticky
    // table header. Adjust the scrollTop if it does.
    .bind('drupalDisplaceFocus.drupal-tableheader', function (event) {
      if (self.stickyVisible && event.clientY < (self.stickyOffsetTop + self.stickyTable.outerHeight()) && event.$target.closest('sticky-header').length === 0) {
        window.scrollBy(0, -self.stickyTable.outerHeight());
      }
    })
    .triggerHandler('resize.drupal-tableheader');

  // We hid the header to avoid it showing up erroneously on page load;
  // we need to unhide it now so that it will show up when expected.
  this.stickyHeader.show();
};

/**
 * Event handler: recalculates position of the sticky table header.
 *
 * @param event
 *   Event being triggered.
 */
Drupal.tableHeader.prototype.eventhandlerRecalculateStickyHeader = function (event) {
  var self = this;
  var calculateWidth = event.data && event.data.calculateWidth;

  // Reset top position of sticky table headers to the current top offset.
  this.stickyOffsetTop = Drupal.settings.tableHeaderOffset ? eval(Drupal.settings.tableHeaderOffset + '()') : 0;
  this.stickyTable.css('top', this.stickyOffsetTop + 'px');

  // Save positioning data.
  var viewHeight = document.documentElement.scrollHeight || document.body.scrollHeight;
  if (calculateWidth || this.viewHeight !== viewHeight) {
    this.viewHeight = viewHeight;
    this.vPosition = this.originalTable.offset().top - 4 - this.stickyOffsetTop;
    this.hPosition = this.originalTable.offset().left;
    this.vLength = this.originalTable[0].clientHeight - 100;
    calculateWidth = true;
  }

  // Track horizontal positioning relative to the viewport and set visibility.
  var hScroll = document.documentElement.scrollLeft || document.body.scrollLeft;
  var vOffset = (document.documentElement.scrollTop || document.body.scrollTop) - this.vPosition;
  this.stickyVisible = vOffset > 0 && vOffset < this.vLength;
  this.stickyTable.css({ left: (-hScroll + this.hPosition) + 'px', visibility: this.stickyVisible ? 'visible' : 'hidden' });

  // Only perform expensive calculations if the sticky header is actually
  // visible or when forced.
  if (this.stickyVisible && (calculateWidth || !this.widthCalculated)) {
    this.widthCalculated = true;
    var $that = null;
    var $stickyCell = null;
    var display = null;
    var cellWidth = null;
    // Resize header and its cell widths.
    // Only apply width to visible table cells. This prevents the header from
    // displaying incorrectly when the sticky header is no longer visible.
    for (var i = 0, il = this.originalHeaderCells.length; i < il; i += 1) {
      $that = $(this.originalHeaderCells[i]);
      $stickyCell = this.stickyHeaderCells.eq($that.index());
      display = $that.css('display');
      if (display !== 'none') {
        cellWidth = $that.css('width');
        // Exception for IE7.
        if (cellWidth === 'auto') {
          cellWidth = $that[0].clientWidth + 'px';
        }
        $stickyCell.css({'width': cellWidth, 'display': display});
      }
      else {
        $stickyCell.css('display', 'none');
      }
    }
    this.stickyTable.css('width', this.originalTable.outerWidth());
  }
};

})(jQuery);
;
